#define LINUX    // else WIN
#ifndef LINUX
	#define WIN
 	#define WINDOWS
#endif
