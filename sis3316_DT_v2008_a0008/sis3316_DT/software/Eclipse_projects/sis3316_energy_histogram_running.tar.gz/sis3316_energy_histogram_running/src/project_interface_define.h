// choose VME Interface
//#define PCI_VME_INTERFACE		// sis1100/3100 optical interface
//#define USB_VME_INTERFACE
#define ETHERNET_UDP_INTERFACE

