//============================================================================
// Name        : sis3316_energy_histogram_running.cpp
// Author      : th
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

#include "project_system_define.h"		//define LINUX or WINDOWS
#include "project_interface_define.h"		//define VME Interface or UDP Interface

#include "get_configuration_parameters.h"


#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>

#include "histogram_shmsizes.h"




#define CERN_ROOT_PLOT

#ifdef CERN_ROOT_PLOT
	#include "rootIncludes.h"
#endif

#ifdef CERN_ROOT_PLOT

#include "sis3316_cern_root_class.h"
sis_root_graph *gl_graph_raw ;
sis_root_graph_maw *gl_graph_maw ;

#endif




/******************************************************************************************************************************/


// choose Interface
#include "vme_interface_class.h"

#ifdef PCI_VME_INTERFACE
	#include "sis1100w_vme_class.h"
	sis1100 *gl_vme_crate ;
#endif

#ifdef USB_VME_INTERFACE
	#include "sis3150w_vme_class.h"
	sis3150 *gl_vme_crate ;
#endif

#ifdef USB3_VME_INTERFACE
	#include "sis3153w_vme_class.h"
	sis3153 *gl_vme_crate ;
#endif




#ifdef ETHERNET_UDP_INTERFACE
	#include "sis3316_ethernet_access_class.h"
	sis3316_eth *gl_vme_crate ;

	#ifdef LINUX
		#include <sys/types.h>
		#include <sys/socket.h>
	#endif

	#ifdef WINDOWS
		#include <winsock2.h>
		#pragma comment(lib, "ws2_32.lib")
		//#pragma comment(lib, "wsock32.lib")
		typedef int socklen_t;
		char  gl_sis3316_ip_addr_string[32] ;

		long WinsockStartup()
		{
		  long rc;

		  WORD wVersionRequested;
		  WSADATA wsaData;
		  wVersionRequested = MAKEWORD(2, 1);

		  rc = WSAStartup( wVersionRequested, &wsaData );
		  return rc;
		}
	#endif

#endif







#ifdef LINUX
//	#include <sys/types.h>
	//#include <sys/socket.h>

	#include <sys/uio.h>

	#include <ctime>
	#include <sys/time.h>
	#include <netinet/in.h>
	#include <arpa/inet.h>
	#include <stdio.h>
	#include <unistd.h>
	#include <errno.h>
	#include <string.h>
	#include <stdlib.h>
#endif


#ifdef WINDOWS
	#include <time.h>
	#include <iostream>
	#include <iomanip>
	using namespace std;

	#define WIN32_LEAN_AND_MEAN
	#include <windows.h>
	#include <tchar.h>
	#include <winsock2.h>
	#include <stdlib.h>
	#include <string.h>

	#pragma comment(lib, "ws2_32.lib")
	//#pragma comment(lib, "wsock32.lib")
	typedef int socklen_t;

	long WinsockStartup()
	{
	  long rc;

	  WORD wVersionRequested;
	  WSADATA wsaData;
	  wVersionRequested = MAKEWORD(2, 1);

	  rc = WSAStartup( wVersionRequested, &wsaData );
	  return rc;
	}

	#include "wingetopt.h"
	void usleep(unsigned int uint_usec) ;

#endif
/* ***************************************************************************************************************** */



//#include "vme_interface_class.h"
//#include "sis3316_ethernet_access_class.h"

#include "sis3316_class.h"
#define			ENERGY_HISTOGRAM_LENGTH 0x10000

//handling cmd line input
char gl_cmd_ip_string[64];
unsigned int gl_cmd_ethernet_device_no = 0;

char gl_command[256];

#define MAX_NUMBER_LWORDS_64MBYTE			0x1000000       /* 64MByte */
//#define MAX_NUMBER_LWORDS_64MBYTE			0x1000000       /* 64MByte */


unsigned int gl_rblt_data[MAX_NUMBER_LWORDS_64MBYTE] ;
FILE *gl_FILE_DataEvenFilePointer ;




sis3316_get_configuration_parameters *gl_sis3316_get_configuration_parameters ;


/*===========================================================================*/
/* Prototypes			                               		  			     */
/*===========================================================================*/

int WriteBufferHeaderCounterNofChannelToDataFile (unsigned int indentifier, unsigned int bank_loop_no, unsigned int channel_no, unsigned int nof_events, unsigned int event_length, unsigned int maw_length, unsigned int reserved);
int WriteEventsToDataFile (unsigned int* memory_data_array, unsigned int nof_write_length_lwords);


/* ***************************************************************************************************************** */
int main(int argc, char* argv[]) {
//int main() {

	int i_arg;
	unsigned int i;
	unsigned int data;

	char ch ;
	char ch_string[64] ;

	char char_config_file[128];
	int configurationFile_rc ;
	unsigned int uint_configurationFile_valid_flag = 0 ;
	unsigned int uint_print_configurationParameterOnly_flag = 0 ;

	char char_messages[128] ;
	unsigned int nof_found_devices ;

	unsigned int clock_N1div, clock_HSdiv ;
	unsigned int iob_delay_value ;




	unsigned int stop_after_loop_counts ;
	unsigned int nof_events ;
	unsigned int trigger_gate_window_length ;
	unsigned int sample_length ;
	unsigned int sample_start_index ;

	unsigned int pre_trigger_delay ;
	unsigned int header_length ;
	unsigned int event_length ;
	unsigned int address_threshold ;
	unsigned int uint_DataEvent_OpenFlag ;
	unsigned int analog_ctrl_val ;
	unsigned int analog_offset_dac_val ;

	unsigned int uint_pileup ;
	unsigned int uint_re_pileup ;

	unsigned int p_val ;
	unsigned int g_val ;
	unsigned int trigger_threshold_value ;

	unsigned int energy_p ;
	unsigned int energy_gap ;
	unsigned int energy_tau ;
	unsigned int energy_average ;

	unsigned int energy_histogram_enable_flag ;
	unsigned int energy_histogram_only_flag ;
	unsigned int energy_histogram_divider_value ;
	unsigned int energy_histogram_offset_value ;



	unsigned int maw_test_buffer_length ;
	unsigned int maw_test_buffer_delay ;
	unsigned int maw_test_buffer_enable_flag ;
	unsigned int maw_test_buffer_select_energy_flag;

	unsigned int header_energy_values_offset ;
	unsigned int uint_trigger_maw_offset ;


	char filename[128]  ;
	unsigned int file_header_indentifier ;

	unsigned int i_ch;
	unsigned int got_nof_32bit_words;

	/******************************************/
	unsigned int uint_onlyIntenalHistogramEnable_config_val ;

/****************************************************************************************************************/
// shared memory

	int shm_histogram_fd;
	size_t shm_histogram_pg_size;
	unsigned int  *uint_shm_histogram_start_ptr;



	unsigned int  *uint_sis3316_histogram_start_ptr;
	unsigned int  *uint_PC_histogram_start_ptr;



	unsigned int uint_pileup_oveflow_flag ;

	unsigned int poll_counter;
	unsigned int plot_counter;
	unsigned int loop_counter;
	unsigned int timeout_counter;
	unsigned int bank1_armed_flag;

	unsigned int bank_buffer_counter ;
	unsigned int ch_event_counter = 0;


	unsigned int uint_channel_event_counter[16];
	unsigned int uint_channel_pileup_counter[16];




/****************************************************************************************************************/
	// default values
/****************************************************************************************************************/

	strcpy(gl_cmd_ip_string,"192.168.1.100") ; // SIS3316 IP address


	uint_DataEvent_OpenFlag      =  0 ;  // save to file

	uint_configurationFile_valid_flag          = 0 ;
	uint_print_configurationParameterOnly_flag = 0 ;

/****************************************************************************************************************/
	// Set Gain/Termination
/****************************************************************************************************************/

	analog_ctrl_val = 0 ; // 5 V Range
	analog_ctrl_val = analog_ctrl_val + 0x01010101 ; // set to 2 V Range
	//analog_ctrl_val = analog_ctrl_val + 0x04040404 ; // disable 50 Ohm Termination

	//set ADC offsets (DAC) :
	//analog_offset_dac_val = 0x8000 ; // middle +/-
	//analog_offset_dac_val = 100 ; // 100 mV - 4.9 V if 5V range
	//analog_offset_dac_val = 13000 ; // 100 mV - 1.9 V if 2V range

	//analog_offset_dac_val = 53000 ; // 0 mV - 2.0 V if 2V range
	analog_offset_dac_val = 51500 ; // 0 mV - 2.0 V if 2V range





/****************************************************************************************************************/
	// Hit/Event sampling parameters
/****************************************************************************************************************/

	stop_after_loop_counts           = 0;    	// 0: endless , could be changed by calling this program with "-N num" option


	//default values
	nof_events                   = 10 ;    // each Bank

	pre_trigger_delay            =  64  ;  //
	sample_length                =  1000; //
	sample_start_index           =  0;
	trigger_gate_window_length   =  1000;

	uint_pileup    = 40;  //
	uint_re_pileup = 40;  //






/****************************************************************************************************************/
	// internal Trigger generation parameters
/****************************************************************************************************************/

// internal trigger FIR
	p_val = 10 ;
	g_val = 10 ;
	trigger_threshold_value =  100  * p_val ; // 2V Range -> 1 bin = 122 uV
	//trigger_threshold_value =  10  * p_val ; // 2V Range -> 1 bin = 122 uV

/****************************************************************************************************************/
	// internal Energy generation parameters
/****************************************************************************************************************/

// internal Energy FIR

	energy_p       = 100 ;
	energy_gap     = 50 ;
	energy_tau     = 0 ;
	energy_average = 3 ;

/****************************************************************************************************************/
	// PC Histogramming parameters
/****************************************************************************************************************/

  	energy_histogram_enable_flag    =  0  ;
  	energy_histogram_only_flag      =  0 ;
  	energy_histogram_divider_value  =  1 ; //
  	energy_histogram_offset_value   =  0; //


/****************************************************************************************************************/
	// maw test buffer
/****************************************************************************************************************/
  	maw_test_buffer_length             = 1000 ;
  	maw_test_buffer_delay              = 100  ;
  	maw_test_buffer_enable_flag        =  0; //
  	maw_test_buffer_select_energy_flag =  0 ; //








  /****************************************************************************************************************/



	/* Save command line into string "command" */
	  memset(gl_command,0,sizeof(gl_command));
	  // memset(startchoice,0,sizeof(startchoice));
	  for (i_arg=0;i_arg<argc;i_arg++) {
	      strcat(gl_command,argv[i_arg]);
	      strcat(gl_command," ");
	  }


	    if (argc > 1) {
		/* Save command line into string "command" */
		memset(gl_command,0,sizeof(gl_command));
		// memset(startchoice,0,sizeof(startchoice));
		for (i_arg=1;i_arg<argc;i_arg++) {
		    strcat(gl_command,argv[i_arg]);
		    strcat(gl_command," ");
		}
		//printf("nof args %d    \n", argc );
		//printf("gl_command %s    \n", gl_command );


		while ((ch = getopt(argc, argv, "?lhpSI:A:N:F:")) != -1)
		  //printf("ch %c    \n", ch );
		  switch (ch) {

		    case 'I':
			sscanf(optarg,"%s", ch_string) ;
			printf("-I %s    \n", ch_string );
			strcpy(gl_cmd_ip_string,ch_string) ;
			break;


		    case 'A':
		    	sscanf(optarg,"%x",&data) ;
		    	gl_cmd_ethernet_device_no = data ;
		    	break;


		    case 'N':
		    	sscanf(optarg,"%d",&data) ;
				stop_after_loop_counts                   = data ;    //
				break;

		    case 'F':
				sscanf(optarg,"%s", char_config_file) ;
				gl_sis3316_get_configuration_parameters      = new sis3316_get_configuration_parameters() ;

				configurationFile_rc = gl_sis3316_get_configuration_parameters->read_parameter_file(char_config_file);
				if (configurationFile_rc != 0) {
					printf("\n" );
					printf("Error on opening configuration File   \n" );
					printf("program stopped !  \n" );
					printf("\n" );
					do {
						usleep(10000) ;
					} while(1) ;
				}
				uint_configurationFile_valid_flag = 1 ;

				break;

		    case 'p':
				uint_print_configurationParameterOnly_flag = 1 ;
				break;

		    case 'S':
		    	uint_DataEvent_OpenFlag      = 1  ;  // save to file
				break;


		    case '?':
		    case 'h':
		    default:
			  //printf("Usage: %s  [-?h] [-I ip] [-A num]  ", argv[0]);
			  printf("Usage: %s  [-?h] [-p] [-I ip] [-N number of loops] [-F filename.ini] [-S] ", argv[0]);
		      printf("   \n");
		      printf("   \n");
		      printf("   -I string  ......  SIS3316 IP Address  Default = %s\n", gl_cmd_ip_string);
		     // printf("       -A num        Ethernet Device Number (0 = ETH0, 1 = ETH1, .. , 3 = ETH3)  Default = %d\n", gl_cmd_ethernet_device_no);
		      printf("   -N num      .....  number of loops (banks); default: 0 (endless) \n");
		      printf("   -F filename .....  configuration file name; for example sis3316_jaea_histogram_running_parameter.ini \n");
		      printf("   \n");
		      printf("   -S     ..........  write to file(s) (sis3316_test_data_N.dat)\n");
		      printf("   \n");
		      printf("   -p     ..........  print the parameter only\n");
		      printf("   \n");
		      printf("   -h     ..........  print this message only\n");
		      printf("   \n");
		      exit(1);
		    }

	      } // if (argc > 2)



/******************************************************************************************************************************/

	     // printf("gl_cmd_ethernet_device_no = %d\n",gl_cmd_ethernet_device_no);
	      usleep(10);



	  	if(uint_configurationFile_valid_flag == 1) { // take parameter from file
		  	nof_events                   = gl_sis3316_get_configuration_parameters->uint_nof_events  ;    // each Bank

		  	pre_trigger_delay            =  gl_sis3316_get_configuration_parameters->uint_pre_trigger_delay  ;  //
		  	sample_length                =  gl_sis3316_get_configuration_parameters->uint_raw_sample_length; //
		  	sample_start_index           =  0;

		  	trigger_gate_window_length   =  gl_sis3316_get_configuration_parameters->uint_trigger_gate_window_length ;
		  	uint_pileup                  =  gl_sis3316_get_configuration_parameters->uint_pileup_window_length;  //
		  	uint_re_pileup               =  gl_sis3316_get_configuration_parameters->uint_re_pileup_window_length ;  //


		  // internal trigger
		  	p_val = gl_sis3316_get_configuration_parameters->uint_trigger_p_value  ;
		  	g_val = gl_sis3316_get_configuration_parameters->uint_trigger_g_value  ;
		  	trigger_threshold_value =  gl_sis3316_get_configuration_parameters->uint_trigger_threshold  * p_val ; // 2V Range -> 1 bin = 122 uV

		  	energy_p = gl_sis3316_get_configuration_parameters->uint_energy_p_value  ;
		  	energy_gap = gl_sis3316_get_configuration_parameters->uint_energy_gap_value  ;
		  	energy_tau =  gl_sis3316_get_configuration_parameters->uint_energy_tau_value ; //
		  	energy_average =  gl_sis3316_get_configuration_parameters->uint_energy_average_value ; //


		  	maw_test_buffer_length = gl_sis3316_get_configuration_parameters->uint_maw_test_buffer_length  ;
		  	maw_test_buffer_delay = gl_sis3316_get_configuration_parameters->uint_maw_test_buffer_delay  ;
		  	maw_test_buffer_enable_flag =  gl_sis3316_get_configuration_parameters->uint_maw_test_buffer_enable_flag ; //
		  	maw_test_buffer_select_energy_flag =  gl_sis3316_get_configuration_parameters->uint_maw_test_buffer_select_energy_flag ; //

		  	energy_histogram_enable_flag = gl_sis3316_get_configuration_parameters->uint_energy_histogram_enable_flag  ;
		  	energy_histogram_only_flag = gl_sis3316_get_configuration_parameters->uint_energy_histogram_only_flag  ;
		  	energy_histogram_divider_value =  gl_sis3316_get_configuration_parameters->uint_energy_histogram_divider_value ; //
		  	energy_histogram_offset_value =  gl_sis3316_get_configuration_parameters->uint_energy_histogram_offset_value ; //

	  	}





		if(uint_print_configurationParameterOnly_flag == 1) { ;

  			printf("\n");
	  		printf("nof_events                         = %d \n",nof_events);
  			printf("\n");
	  		printf("pre_trigger_delay                  = %d \n", pre_trigger_delay);
	  		printf("raw_sample_length                  = %d \n", sample_length);
  			printf("\n");
	  		printf("trigger_gate_window_length         = %d \n", trigger_gate_window_length);
	  		printf("pileup_window_length               = %d \n", uint_pileup);
	  		printf("re_pileup_window_length            = %d \n", uint_re_pileup);
  			printf("\n");

	  		printf("trigger_threshold_value*p_val      = %d \n",trigger_threshold_value );
	  		printf("trigger_p_value                    = %d \n",p_val );
	  		printf("trigger_g_value                    = %d \n",g_val);
  			printf("\n");

	  		printf("energy_p_value                     = %d \n",energy_p );
	  		printf("energy_gap_value                   = %d \n",energy_gap );
	  		printf("energy_tau_value                   = %d \n",energy_tau );
	  		printf("energy_average_value               = %d \n",energy_average );
  			printf("\n");

	  		printf("maw_test_buffer_length_value       = %d \n",maw_test_buffer_length );
	  		printf("maw_test_buffer_delay_value        = %d \n",maw_test_buffer_delay );
	  		printf("maw_test_buffer_enable_flag        = %d \n",maw_test_buffer_enable_flag );
	  		printf("maw_test_buffer_select_energy_flag = %d \n",maw_test_buffer_select_energy_flag );
  			printf("\n");

	  		printf("energy_histogram_enable_flag       = %d \n",energy_histogram_enable_flag );
	  		printf("energy_histogram_only_flag         = %d \n",energy_histogram_only_flag );
	  		printf("energy_histogram_divider_value     = %d \n",energy_histogram_divider_value );
	  		printf("energy_histogram_offset_value      = %d \n",energy_histogram_offset_value );
  			printf("\n");




	  		printf("\n");
	 		printf("\n");
		    exit(1);

		}







#ifdef ETHERNET_UDP_INTERFACE

	char  pc_ip_addr_string[32] ;
	char  sis3316_ip_addr_string[32] ;
	int return_code ;

	strcpy(sis3316_ip_addr_string, gl_cmd_ip_string) ; // SIS3316 IP address
	//strcpy(sis3316_ip_addr_string,"212.60.16.200") ; // SIS3316 IP address
	//strcpy(sis3316_ip_addr_string,"192.168.1.100") ; // SIS3316 IP address
	#ifdef WINDOWS
    //return_code = WSAStartup();
    return_code = WinsockStartup();
	#endif
	sis3316_eth *vme_crate = new sis3316_eth;
	// increase read_buffer size
	// SUSE needs following command as su: >sysctl -w net.core.rmem_max=33554432
	int	sockbufsize = 335544432 ; // 0x2000000
	return_code = vme_crate->set_UdpSocketOptionBufSize(sockbufsize) ;

	//strcpy(pc_ip_addr_string,"212.60.16.49") ; // Window example: secocnd Lan interface IP address is 212.60.16.49
	strcpy(pc_ip_addr_string,"") ; // empty if default Lan interface (Window: use IP address to bind in case of 2. 3. 4. .. LAN Interface)
	return_code = vme_crate->set_UdpSocketBindMyOwnPort( pc_ip_addr_string);

	vme_crate->set_UdpSocketSIS3316_IpAddress( sis3316_ip_addr_string);

	vme_crate->udp_reset_cmd();
	vme_crate->vme_A32D32_write(SIS3316_INTERFACE_ACCESS_ARBITRATION_CONTROL, 0x80000000); // kill request and grant from other vme interface
	vme_crate->vme_A32D32_write(SIS3316_INTERFACE_ACCESS_ARBITRATION_CONTROL, 0x1); // request access to SIS3316 from UDP interface

    return_code = vme_crate->vme_A32D32_read(SIS3316_MODID,&data);
	printf("return_code = 0X%08x   Module ID = 0X%08x \n",return_code, data);
    return_code = vme_crate->vme_A32D32_read(SIS3316_INTERFACE_ACCESS_ARBITRATION_CONTROL,&data);
	printf("return_code = 0X%08x   ACCESS    = 0X%08x \n",return_code, data);

#endif

	// open Vme Interface device
	return_code = vme_crate->vmeopen ();  // open Vme interface
	vme_crate->get_vmeopen_messages (char_messages, &nof_found_devices);  // open Vme interface
    printf("get_vmeopen_messages = %s , nof_found_devices %d \n",char_messages, nof_found_devices);

/*************************************************************************************************************************/

	sis3316_adc  *sis3316_adc1 ;
	sis3316_adc1 = new sis3316_adc( vme_crate, 0x0);

	return_code = sis3316_adc1->register_read(SIS3316_MODID, &data);
	printf("sis3316_adc1->register_read: return_code = 0X%08x   data = 0X%08x \n",return_code, data);

	if(return_code != 0) {
		printf("Error: no connection to SIS3316 !! \n");
		return -1 ;
	}




/****************************************************************************************************************/
	// shared memory
	shm_histogram_fd=shm_open("SIS3316_SHM_HISTOGRAM_BUF", O_RDWR | O_CREAT ,0);
	printf("return code: shm_open SIS3316_SHM_HISTOGRAM_BUF: %8x \n",shm_histogram_fd);
	if (shm_histogram_fd < 0) {
	return(-1);
	}
	system("chmod 666 /dev/shm/SIS3316_SHM_HISTOGRAM_BUF");
	shm_histogram_pg_size = SHM_ENERGY_HISTOGRAM_SIZE;

	if((ftruncate(shm_histogram_fd, shm_histogram_pg_size)) == -1){    /* Set the size */
		perror("ftruncate failure");
		exit(0);
	}



	/* Map   */
	uint_shm_histogram_start_ptr = (unsigned int *)mmap(0, shm_histogram_pg_size, PROT_WRITE, MAP_SHARED, shm_histogram_fd, 0);

	// clear shared memory
	for (i=0;i<(shm_histogram_pg_size/4);i++) {
		uint_shm_histogram_start_ptr[i] = 0 ;
	}


	uint_sis3316_histogram_start_ptr = uint_shm_histogram_start_ptr + SHM_SIS3316_HISTOGRAM_OFFSET ;
	uint_PC_histogram_start_ptr      = uint_shm_histogram_start_ptr + SHM_PC_HISTOGRAM_OFFSET ;




	/******************************************************************************************************************************/
	/* CERN ROOT                                                                                                                  */
	/******************************************************************************************************************************/


	#ifdef CERN_ROOT_PLOT

		int root_graph_x ;
		int root_graph_y ;
		int root_graph_x_size ;
		int root_graph_y_size ;
		char root_graph_text[80] ;

		root_graph_x_size = 1000 ;
		root_graph_y_size = 500 ;

		root_graph_x = 10 ;
		root_graph_y = 10 ;

		TApplication theApp("SIS3316 Application: Test", &argc, (char**)argv);
		strcpy(root_graph_text,"SIS3316 Graph: Raw data") ;
		gl_graph_raw      = new sis_root_graph(root_graph_text, root_graph_x, root_graph_y, root_graph_x_size, root_graph_y_size) ;

		strcpy(root_graph_text,"SIS3316 Graph: Moving Window") ;
		gl_graph_maw      = new sis_root_graph_maw(root_graph_text, root_graph_x, root_graph_y+root_graph_y_size+10, root_graph_x_size, root_graph_y_size) ;


		if (sis3316_adc1->adc_125MHz_flag == 0) {
			gl_graph_raw->sis3316_set_14bit_Yaxis() ;// 250 MHz
		}
		else {
			gl_graph_raw->sis3316_set_16bit_Yaxis() ;// 125 MHz
		}
#endif

/*************************************************************************************************************************/
	if (sis3316_adc1->adc_125MHz_flag == 0) {
		// 250  MHz
		file_header_indentifier      =  0  ;
	}
	else {
		// 125 MHz
		file_header_indentifier      =  1  ;
	}

/*  Hardware configuration of the SIS3316 */

	return_code = sis3316_adc1->register_write(SIS3316_KEY_RESET, 0);
	return_code = sis3316_adc1->register_write(SIS3316_KEY_DISARM, 0);

	if (sis3316_adc1->adc_125MHz_flag == 0) {
		// 250  MHz
		printf("250 !! \n");
		clock_N1div      =  4  ;
		clock_HSdiv      =  5  ;
		//iob_delay_value  =  0x48   ; // ADC FPGA version A_0250_0003
		iob_delay_value  =  0x1008 ; // ADC FPGA version A_0250_0004 and higher
	}
	else {
		// 125 MHz
		printf("125 !! \n");
		clock_N1div      =  8  ;
		clock_HSdiv      =  5  ;
		//iob_delay_value  =  0x7F   ; // ADC FPGA version A_0250_0003
		iob_delay_value  =  0x1020 ; // ADC FPGA version A_0250_0004 and higher
	}

	sis3316_adc1->change_frequency_HSdiv_N1div(0, clock_HSdiv, clock_N1div) ;
	usleep(1000) ;

	// enable ADC chip outputs
	for (i=0;i<4;i++) {
		return_code = sis3316_adc1->register_write((i*SIS3316_FPGA_ADC_REG_OFFSET) + SIS3316_ADC_CH1_4_SPI_CTRL_REG, 0x01000000 ); // enable ADC chip outputs
	}

	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH1_4_INPUT_TAP_DELAY_REG, 0xf00 ); // Calibrate IOB _delay Logic
	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH5_8_INPUT_TAP_DELAY_REG, 0xf00 ); // Calibrate IOB _delay Logic
	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH9_12_INPUT_TAP_DELAY_REG, 0xf00 ); // Calibrate IOB _delay Logic
	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH13_16_INPUT_TAP_DELAY_REG, 0xf00 ); // Calibrate IOB _delay Logic
	usleep(1000) ;
	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH1_4_INPUT_TAP_DELAY_REG, 0x300 + iob_delay_value ); // set IOB _delay Logic
	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH5_8_INPUT_TAP_DELAY_REG, 0x300 + iob_delay_value ); // set IOB _delay Logic
	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH9_12_INPUT_TAP_DELAY_REG, 0x300 + iob_delay_value ); // set IOB _delay Logic
	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH13_16_INPUT_TAP_DELAY_REG, 0x300 + iob_delay_value ); // set IOB _delay Logic
	usleep(1000) ;


/******************************************/

	// Select LEMO Output "Co"
	data = 0x1 ; // Select Sample Clock
	return_code = sis3316_adc1->register_write(SIS3316_LEMO_OUT_CO_SELECT_REG, data ); //

	// Enable LEMO Output "TO"
	data = 0xffff ; // Select all triggers
	data = 0x0001 ; // Select channel 1 trigger
	return_code = sis3316_adc1->register_write(SIS3316_LEMO_OUT_TO_SELECT_REG, data ); //

	// Enable LEMO Output "UO"
	data = 0x10 ; //
	return_code = sis3316_adc1->register_write(SIS3316_LEMO_OUT_UO_SELECT_REG, data ); //

/******************************************/

	data = 0x0 ;
	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH1_4_CHANNEL_HEADER_REG, data); //
	data = 0x00400000 ;
	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH5_8_CHANNEL_HEADER_REG, data ); //
	data = 0x00800000 ;
	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH9_12_CHANNEL_HEADER_REG, data ); //
	data = 0x00C00000 ;
	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH13_16_CHANNEL_HEADER_REG, data ); //

/******************************************/
#ifdef raus
	// set ADC chips via SPI
	for (i=0;i<4;i++) {
		return_code = sis3316_adc1->register_write((i*SIS3316_FPGA_ADC_REG_OFFSET) + SIS3316_ADC_CH1_4_SPI_CTRL_REG, 0x81001404 ); // SPI (OE)  set binary
		usleep(10); //unsigned int uint_usec
		return_code = sis3316_adc1->register_write((i*SIS3316_FPGA_ADC_REG_OFFSET) + SIS3316_ADC_CH1_4_SPI_CTRL_REG, 0x81401404 ); // SPI (OE)  set binary
		usleep(10); //unsigned int uint_usec
		return_code = sis3316_adc1->register_write((i*SIS3316_FPGA_ADC_REG_OFFSET) + SIS3316_ADC_CH1_4_SPI_CTRL_REG, 0x8100ff01 ); // SPI (OE)  update
		usleep(10); //unsigned int uint_usec
		return_code = sis3316_adc1->register_write((i*SIS3316_FPGA_ADC_REG_OFFSET) + SIS3316_ADC_CH1_4_SPI_CTRL_REG, 0x8140ff01 ); // SPI (OE)  update
		usleep(10); //unsigned int uint_usec
	}
#endif
		/******************************************/

	// Gain/Termination
	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH1_4_ANALOG_CTRL_REG, analog_ctrl_val); //
	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH5_8_ANALOG_CTRL_REG, analog_ctrl_val ); //
	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH9_12_ANALOG_CTRL_REG, analog_ctrl_val ); //
	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH13_16_ANALOG_CTRL_REG, analog_ctrl_val ); //

	//
	//  set ADC offsets (DAC)
	for (i=0;i<4;i++) { // over all 4 ADC-FPGAs
		return_code = sis3316_adc1->register_write((i*SIS3316_FPGA_ADC_REG_OFFSET) + SIS3316_ADC_CH1_4_DAC_OFFSET_CTRL_REG, 0x80000000 + 0x8000000 +  0xf00000 + 0x1);  // set internal Reference
		usleep(1); //unsigned int uint_usec
		return_code = sis3316_adc1->register_write((i*SIS3316_FPGA_ADC_REG_OFFSET) + SIS3316_ADC_CH1_4_DAC_OFFSET_CTRL_REG, 0x80000000 + 0x2000000 +  0xf00000 + ((analog_offset_dac_val & 0xffff) << 4) );  //
		//return_code = sis3316_adc1->register_write((i*SIS3316_FPGA_ADC_REG_OFFSET) + SIS3316_ADC_CH1_4_DAC_OFFSET_CTRL_REG, 0x80000000 + 0x2000000 +  0xf00000 + ((15000 & 0xffff) << 4) );  //
		return_code = sis3316_adc1->register_write((i*SIS3316_FPGA_ADC_REG_OFFSET) + SIS3316_ADC_CH1_4_DAC_OFFSET_CTRL_REG, 0xC0000000 );  //
		usleep(1); //unsigned int uint_usec
	}


/******************************************/


	// disable all FIR Triggers
	data = 0x00000000 ;
	for (i=0; i<4; i++) {
		return_code = sis3316_adc1->register_write((i*SIS3316_FPGA_ADC_REG_OFFSET) + SIS3316_ADC_CH1_FIR_TRIGGER_THRESHOLD_REG, data );  // disable ch1, 5, 9, 13
		return_code = sis3316_adc1->register_write((i*SIS3316_FPGA_ADC_REG_OFFSET) + SIS3316_ADC_CH2_FIR_TRIGGER_THRESHOLD_REG, data );  // disable ch2, ..
		return_code = sis3316_adc1->register_write((i*SIS3316_FPGA_ADC_REG_OFFSET) + SIS3316_ADC_CH3_FIR_TRIGGER_THRESHOLD_REG, data );  // disable ch3, ..
		return_code = sis3316_adc1->register_write((i*SIS3316_FPGA_ADC_REG_OFFSET) + SIS3316_ADC_CH4_FIR_TRIGGER_THRESHOLD_REG, data );  // disable ch4, ..
	}


	// set HighEnergy Threshold
	data =  0x08000000 + (p_val * 1000) ; // gt 1000
	for (i=0; i<4; i++) {
		return_code = sis3316_adc1->register_write((i*SIS3316_FPGA_ADC_REG_OFFSET) + SIS3316_ADC_CH1_FIR_HIGH_ENERGY_THRESHOLD_REG, data );  //
		return_code = sis3316_adc1->register_write((i*SIS3316_FPGA_ADC_REG_OFFSET) + SIS3316_ADC_CH2_FIR_HIGH_ENERGY_THRESHOLD_REG, data );  //
		return_code = sis3316_adc1->register_write((i*SIS3316_FPGA_ADC_REG_OFFSET) + SIS3316_ADC_CH3_FIR_HIGH_ENERGY_THRESHOLD_REG, data );  //
		return_code = sis3316_adc1->register_write((i*SIS3316_FPGA_ADC_REG_OFFSET) + SIS3316_ADC_CH4_FIR_HIGH_ENERGY_THRESHOLD_REG, data );  //
	}


	// set FIR Trigger Setup
	for (i=0; i<4; i++) {
		data =  p_val + (g_val << 12) ; //
		return_code = sis3316_adc1->register_write((i*SIS3316_FPGA_ADC_REG_OFFSET) + SIS3316_ADC_CH1_FIR_TRIGGER_SETUP_REG, 0 );  //
		return_code = sis3316_adc1->register_write((i*SIS3316_FPGA_ADC_REG_OFFSET) + SIS3316_ADC_CH1_FIR_TRIGGER_SETUP_REG, data );  //
		return_code = sis3316_adc1->register_write((i*SIS3316_FPGA_ADC_REG_OFFSET) + SIS3316_ADC_CH2_FIR_TRIGGER_SETUP_REG, 0 );  //
		return_code = sis3316_adc1->register_write((i*SIS3316_FPGA_ADC_REG_OFFSET) + SIS3316_ADC_CH2_FIR_TRIGGER_SETUP_REG, data );  //
		return_code = sis3316_adc1->register_write((i*SIS3316_FPGA_ADC_REG_OFFSET) + SIS3316_ADC_CH3_FIR_TRIGGER_SETUP_REG, 0 );  //
		return_code = sis3316_adc1->register_write((i*SIS3316_FPGA_ADC_REG_OFFSET) + SIS3316_ADC_CH3_FIR_TRIGGER_SETUP_REG, data );  //
		return_code = sis3316_adc1->register_write((i*SIS3316_FPGA_ADC_REG_OFFSET) + SIS3316_ADC_CH4_FIR_TRIGGER_SETUP_REG, 0 );  //
		return_code = sis3316_adc1->register_write((i*SIS3316_FPGA_ADC_REG_OFFSET) + SIS3316_ADC_CH4_FIR_TRIGGER_SETUP_REG, data );  //
	}

// configure Fir trigger logic
	data =  0xB0000000 + 0x08000000 + trigger_threshold_value ;  // cfd 50
	//data =  0xA0000000 + 0x08000000 + trigger_threshold_value ;  // cfd zero crossing
	for (i=0; i<4; i++) {
		return_code = sis3316_adc1->register_write((i*SIS3316_FPGA_ADC_REG_OFFSET) + SIS3316_ADC_CH1_FIR_TRIGGER_THRESHOLD_REG, data );  //
		return_code = sis3316_adc1->register_write((i*SIS3316_FPGA_ADC_REG_OFFSET) + SIS3316_ADC_CH2_FIR_TRIGGER_THRESHOLD_REG, data );  //
		return_code = sis3316_adc1->register_write((i*SIS3316_FPGA_ADC_REG_OFFSET) + SIS3316_ADC_CH3_FIR_TRIGGER_THRESHOLD_REG, data );  //
		return_code = sis3316_adc1->register_write((i*SIS3316_FPGA_ADC_REG_OFFSET) + SIS3316_ADC_CH4_FIR_TRIGGER_THRESHOLD_REG, data );  //
	}



/******************************************/
	//pileup ;
	data = ((uint_re_pileup & 0xffff) << 16) + (uint_pileup & 0xffff) ;
	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH1_4_PILEUP_CONFIG_REG, data); //
	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH5_8_PILEUP_CONFIG_REG, data); //
	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH9_12_PILEUP_CONFIG_REG, data); //
	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH13_16_PILEUP_CONFIG_REG, data); //

	/******************************************/


	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH1_4_TRIGGER_GATE_WINDOW_LENGTH_REG, ((trigger_gate_window_length -2) & 0xffff) ); // trigger_gate_window_length
	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH5_8_TRIGGER_GATE_WINDOW_LENGTH_REG, ((trigger_gate_window_length -2) & 0xffff) ); // trigger_gate_window_length
	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH9_12_TRIGGER_GATE_WINDOW_LENGTH_REG, ((trigger_gate_window_length -2) & 0xffff) ); // trigger_gate_window_length
	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH13_16_TRIGGER_GATE_WINDOW_LENGTH_REG, ((trigger_gate_window_length -2) & 0xffff) ); // trigger_gate_window_length

	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH1_4_RAW_DATA_BUFFER_CONFIG_REG, ((sample_length & 0xffff) << 16) + (sample_start_index & 0xffff) ); // Sample Length
	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH5_8_RAW_DATA_BUFFER_CONFIG_REG, ((sample_length & 0xffff) << 16) + (sample_start_index & 0xffff) ); // Sample Length
	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH9_12_RAW_DATA_BUFFER_CONFIG_REG, ((sample_length & 0xffff) << 16) + (sample_start_index & 0xffff) ); // Sample Length
	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH13_16_RAW_DATA_BUFFER_CONFIG_REG, ((sample_length & 0xffff) << 16) + (sample_start_index & 0xffff) ); // Sample Length

/******************************************/

	pre_trigger_delay = pre_trigger_delay + p_val + (p_val>>1) + g_val + 16 + 16;  // 16 is additional delay for 50% CFD trigger --> see edge at index 10

	if (pre_trigger_delay > 2042) {
		pre_trigger_delay  = 2042 ;
	}
	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH1_4_PRE_TRIGGER_DELAY_REG, pre_trigger_delay ); //
	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH5_8_PRE_TRIGGER_DELAY_REG, pre_trigger_delay ); //
	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH9_12_PRE_TRIGGER_DELAY_REG, pre_trigger_delay ); //
	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH13_16_PRE_TRIGGER_DELAY_REG, pre_trigger_delay ); //

/******************************************/

	// Enable LEMO Input "TI" as External Trigger
	unsigned int uint_nim_input_ctrl ;

	uint_nim_input_ctrl = 0x10 ; // Enable Nim Input "TI"
	uint_nim_input_ctrl = uint_nim_input_ctrl + 0x40 ; // Level sensitiv

	// Enable LEMO Input "UI" as Timestamp Clear (Restart)
	uint_nim_input_ctrl = uint_nim_input_ctrl + 0x100 ; // Enable Nim Input "UI" as
	return_code = sis3316_adc1->register_write(SIS3316_NIM_INPUT_CONTROL_REG, uint_nim_input_ctrl ); //

/******************************************/

	//  Event Configuration

	data = 0x04040404 ; // internal trigger ch4 , ch3, ch2 ch1
	//data = data + 0x01010101 ; // signal Invert ch4 , ch3, ch2 ch1
	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH1_4_EVENT_CONFIG_REG, data ); //
	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH5_8_EVENT_CONFIG_REG, data ); //
	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH9_12_EVENT_CONFIG_REG, data ); //
	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH13_16_EVENT_CONFIG_REG, data ); //  r

	/******************************************/
	// data format


	maw_test_buffer_delay  = maw_test_buffer_delay + p_val + (p_val>>1) + g_val   ;
	if (maw_test_buffer_delay > 1024) {
		maw_test_buffer_delay  = 1024 ;
	}




	// set bit 3
	// data format
	header_length = 5;	// 2 x Timestamps and channelId/Header + 2 Energy + Trailor
	header_energy_values_offset  = 2 ;		// 2 x Timestamps and channelId/Header

	data = 0x8 ; // set bit 3
	uint_trigger_maw_offset = 0x08000000 ; // trigger MAW has an offset of 0x08000000
	if (maw_test_buffer_enable_flag == 1) {
		data = data + 0x10 ; // set bit 4
		if (maw_test_buffer_select_energy_flag == 1) {
			data = data + 0x20 ; // set bit 5 -> select Energy Filter
			uint_trigger_maw_offset = 0x0 ; // enegy offset
		}
	}
	else {
		maw_test_buffer_length = 0 ; // disabled
	}
	data = data + (data << 8) + (data << 16) + (data << 24);
	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH1_4_DATAFORMAT_CONFIG_REG, data );
	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH5_8_DATAFORMAT_CONFIG_REG, data );
	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH9_12_DATAFORMAT_CONFIG_REG, data );
	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH13_16_DATAFORMAT_CONFIG_REG, data );



/******************************************/
// Energy Filter
	data = ((energy_tau & 0xff) << 24) + ((energy_average & 0x3) << 22) + ((energy_gap & 0x3ff) << 12) + (energy_p & 0xfff) ;
	for (i=0; i<4; i++) { // i_adc_fpga
		return_code = sis3316_adc1->register_write((i*SIS3316_FPGA_ADC_REG_OFFSET) + SIS3316_ADC_CH1_FIR_ENERGY_SETUP_REG, data);
		return_code = sis3316_adc1->register_write((i*SIS3316_FPGA_ADC_REG_OFFSET) + SIS3316_ADC_CH2_FIR_ENERGY_SETUP_REG, data);
		return_code = sis3316_adc1->register_write((i*SIS3316_FPGA_ADC_REG_OFFSET) + SIS3316_ADC_CH3_FIR_ENERGY_SETUP_REG, data);
		return_code = sis3316_adc1->register_write((i*SIS3316_FPGA_ADC_REG_OFFSET) + SIS3316_ADC_CH4_FIR_ENERGY_SETUP_REG, data);
	}
	//printf("data = 0x%08x     \n", data);


/******************************************/
//    histogram Memory parameter



	data =   ((energy_histogram_only_flag & 0x1) << 31) // disable capturing of Hits/Events
		   + ((energy_histogram_divider_value & 0xfff) << 16)
		   + ((energy_histogram_offset_value& 0xff) << 8)   // index offset * 0x100
		   + 0   // if 1 : enable if Pileup
		   + (energy_histogram_enable_flag & 0x1) ; // enable
	for (i=0; i<4; i++) {
		return_code = sis3316_adc1->register_write((i*SIS3316_FPGA_ADC_REG_OFFSET) + SIS3316_ADC_CH1_HISTOGRAM_CONF_REG, data);
		return_code = sis3316_adc1->register_write((i*SIS3316_FPGA_ADC_REG_OFFSET) + SIS3316_ADC_CH2_HISTOGRAM_CONF_REG, data);
		return_code = sis3316_adc1->register_write((i*SIS3316_FPGA_ADC_REG_OFFSET) + SIS3316_ADC_CH3_HISTOGRAM_CONF_REG, data);
		return_code = sis3316_adc1->register_write((i*SIS3316_FPGA_ADC_REG_OFFSET) + SIS3316_ADC_CH4_HISTOGRAM_CONF_REG, data);
	}




/******************************************/

// MAW Test Buffer configuration
	data = maw_test_buffer_length + (maw_test_buffer_delay << 16) ;
	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH1_4_MAW_TEST_BUFFER_CONFIG_REG, data );
	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH5_8_MAW_TEST_BUFFER_CONFIG_REG, data );
	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH9_12_MAW_TEST_BUFFER_CONFIG_REG, data );
	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH13_16_MAW_TEST_BUFFER_CONFIG_REG, data );

/******************************************/
	event_length = (header_length + (sample_length / 2)  + maw_test_buffer_length);

	//address_threshold = 200;
	address_threshold = (nof_events * event_length) - 1 ;  //
	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH1_4_ADDRESS_THRESHOLD_REG, address_threshold ); //
	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH5_8_ADDRESS_THRESHOLD_REG, address_threshold); //
	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH9_12_ADDRESS_THRESHOLD_REG, address_threshold ); //
	return_code = sis3316_adc1->register_write(SIS3316_ADC_CH13_16_ADDRESS_THRESHOLD_REG, address_threshold ); //

/******************************************************************************************/

	if (sample_length != 0) {
		gl_graph_raw->sis3316_draw_XYaxis (sample_length); // clear and draw X/Y
	}


/******************************************************************************************/

	for (i_ch=0; i_ch<16; i_ch++) {
		uint_channel_event_counter[i_ch]  = 0;
		uint_channel_pileup_counter[i_ch] = 0;
	}




	plot_counter=0;
	loop_counter=0;
	timeout_counter = 0 ;

	printf("Start Multievent \n");

	bank_buffer_counter = 0 ;

	// enbale external (global) functions
	//data = 0x200 ; // enable "external Trigger function"  as Veto (NIM In, if enabled and VME key write)

	data = 0x0 ; //
	data = data + 0x400 ; // enable "external Timestamp clear and Histogram clear function" (NIM In, if enabled and VME key write)
	return_code = sis3316_adc1->register_write(SIS3316_ACQUISITION_CONTROL_STATUS, data );

	// Clear Timestamp and Energy Histograms
	return_code = sis3316_adc1->register_write(SIS3316_KEY_TIMESTAMP_CLEAR , 0);  //
	//usleep(40000) ; // 40 ms ; needs the Clear Energy Histogram Logic

	// Start Readout Loop  */
	return_code = sis3316_adc1->register_write(SIS3316_KEY_DISARM_AND_ARM_BANK1 , 0);  //  Arm Bank1
	bank1_armed_flag = 1; // start condition
	printf("SIS3316_KEY_DISARM_AND_ARM_BANK1 \n");


	uint_onlyIntenalHistogramEnable_config_val = 0  ;  // Hits/Events capturing
	if ((energy_histogram_enable_flag == 1) && (energy_histogram_only_flag == 1)) {
		uint_onlyIntenalHistogramEnable_config_val = 1  ;  // Hits/Events capturing disable
	}

	if (sample_length != 0) {
		gl_graph_raw->sis3316_draw_XYaxis (sample_length); // clear and draw X/Y
	}

	do {

		if ((uint_onlyIntenalHistogramEnable_config_val & 0x1) == 0){

			poll_counter = 0 ;
			sis3316_adc1->register_read(SIS3316_ACQUISITION_CONTROL_STATUS, &data);
			do {
				poll_counter++;
				if (poll_counter == 100) {
					gSystem->ProcessEvents();  // handle GUI events
					poll_counter = 0 ;
				}
				sis3316_adc1->register_read(SIS3316_ACQUISITION_CONTROL_STATUS, &data);
				//usleep(500000); //500ms
				//printf("in Loop:   SIS3316_ACQUISITION_CONTROL_STATUS = 0x%08x     \n", data);
			} while ((data & 0x80000) == 0x0) ; // Address Threshold reached ?


			if (bank1_armed_flag == 1) {
				return_code = sis3316_adc1->register_write(SIS3316_KEY_DISARM_AND_ARM_BANK2 , 0);  //  Arm Bank2
				bank1_armed_flag = 0; // bank 2 is armed
				printf("SIS3316_KEY_DISARM_AND_ARM_BANK2 \n");
			}
			else {
				return_code = sis3316_adc1->register_write(SIS3316_KEY_DISARM_AND_ARM_BANK1 , 0);  //  Arm Bank1
				bank1_armed_flag = 1; // bank 1 is armed
				printf("SIS3316_KEY_DISARM_AND_ARM_BANK1 \n");
			}

			// file write
			if (uint_DataEvent_OpenFlag == 1) {   ; // Open
				sprintf(filename,"sis3316_test_data_%d.dat",bank_buffer_counter ) ;
				printf("%s\n",filename) ;
				gl_FILE_DataEvenFilePointer = fopen(filename,"wb") ;
				//gl_FILE_DataEvenFilePointer = fopen("sis3316_test_data.dat","wb") ;
			}


			//gl_graph_raw->sis3316_draw_XYaxis (sample_length); // clear and draw X/Y
			for (i_ch=0; i_ch<16; i_ch++) {
				// read channel events
				//return_code = sis3316_adc1->read_DMA_Channel_PreviousBankDataBuffer(bank1_armed_flag /*bank2_read_flag*/, i_ch /* 0 to 15 */, nof_events * event_length, &got_nof_32bit_words, gl_rblt_data ) ;
				return_code = sis3316_adc1->read_MBLT64_Channel_PreviousBankDataBuffer(bank1_armed_flag /*bank2_read_flag*/, i_ch /* 0 to 15 */,  &got_nof_32bit_words, gl_rblt_data ) ;
				if (return_code != 0) {
					printf("read_MBLT64_Channel_PreviousBankDataBuffer: return_code = 0x%08x\n", return_code);
					//gl_stopReq = TRUE;
				}
				ch_event_counter = (got_nof_32bit_words  / event_length) ;
				uint_channel_event_counter[i_ch]  = uint_channel_event_counter[i_ch] + ch_event_counter;
				if (ch_event_counter > 0) {
					printf("read_Channel_PreviousBankDataBuffer: i_ch %d  got_nof_32bit_words = 0x%08x  return_code = 0x%08x\n",i_ch+1,  got_nof_32bit_words, return_code);
					printf("ch%d  event_counter = %d     \n", i_ch+1 , ch_event_counter);
					// build histograms
					for (i=0; i<ch_event_counter; i++) {

					//	printf("data = 0x%08x  \n",(gl_rblt_data[i*(event_length) + (header_length-1)] ) );

						uint_pileup_oveflow_flag = 0;
							if ((gl_rblt_data[i*(event_length) + (header_length-1)] & 0x04000000) != 0) { //
								uint_pileup_oveflow_flag = 1;
							}
						if (uint_pileup_oveflow_flag == 0) { // no pileups no Over/Underflow
							uint_pileup_oveflow_flag = 0;

						}
						else { // pileup or overflow
							uint_channel_pileup_counter[i_ch]++;
						}

					}

/******************/

// Test prints of values and plot raw data
					if (bank_buffer_counter == 0)   { // plot only the first time
						//if (bank_buffer_counter < 10000)   {
					// plot events
						for (i=0; i<ch_event_counter; i++) {
							if (i<10) { // plot only 10 event at the beginning
								if (sample_length != 0) {
									gl_graph_raw->sis3316_draw_chN (sample_length, &gl_rblt_data[i*(event_length) + header_length], i_ch); //
								}
							}

							if (i<10) { // plot only 10 event at the beginning
								if (maw_test_buffer_enable_flag != 0) {
									gl_graph_maw->sis3316_draw_trigger_and_energy_mawN(maw_test_buffer_length, &gl_rblt_data[i*(event_length) + header_length + (sample_length/2)], i_ch, uint_trigger_maw_offset); //
								}
							}

						}
					}


					if (uint_DataEvent_OpenFlag == 1) {   ; // Open
						WriteBufferHeaderCounterNofChannelToDataFile (file_header_indentifier, bank_buffer_counter, i_ch, ch_event_counter, event_length , maw_test_buffer_length, 0 /* reserved */ ) ;
						WriteEventsToDataFile (gl_rblt_data, got_nof_32bit_words)  ;
					}


				}
			}
			if (uint_DataEvent_OpenFlag == 1) {   ; // Open
				fclose(gl_FILE_DataEvenFilePointer);
			}


			for (i_ch=0; i_ch<16; i_ch++) {
				uint_sis3316_histogram_start_ptr  = uint_shm_histogram_start_ptr + (i_ch * SHM_ENERGY_HISTOGRAM_CHANNEL_OFFSET) ;
				return_code = sis3316_adc1->read_Channel_EnergyHistogramBuffer(i_ch /*i_ch*/,  ENERGY_HISTOGRAM_LENGTH, uint_sis3316_histogram_start_ptr ) ;
			}

#ifdef test
			uint_sis3316_histogram_start_ptr  = uint_shm_histogram_start_ptr ;
			for (i_ch=0; i_ch<0x10000; i_ch++) {
				uint_sis3316_histogram_start_ptr[i_ch] = i_ch ;
			}
#endif
			loop_counter++;
			bank_buffer_counter++;

			printf("bank_buffer_counter = %d     \n",bank_buffer_counter);
			for (i_ch=0; i_ch<16; i_ch++) {
				if (uint_channel_event_counter[i_ch] != 0) {
					printf("ch %d    event counter  = %d     pileup_counter = %d   \n", i_ch+1, uint_channel_event_counter[i_ch], uint_channel_pileup_counter[i_ch]);
				}
			}


			printf("\n");
			//printf("ch_event_counter    = %d     \n", ch_event_counter);
			gSystem->ProcessEvents();  // handle GUI events



		}
		else {
			gSystem->ProcessEvents();  // handle GUI events
			usleep(400000) ;
			printf("reading internal Energy Histograms   \n");

			for (i_ch=0; i_ch<16; i_ch++) {
				uint_sis3316_histogram_start_ptr  = uint_shm_histogram_start_ptr + (i_ch * SHM_ENERGY_HISTOGRAM_CHANNEL_OFFSET) + SHM_SIS3316_HISTOGRAM_OFFSET;
				return_code = sis3316_adc1->read_Channel_EnergyHistogramBuffer(i_ch /*i_ch*/,  ENERGY_HISTOGRAM_LENGTH, uint_sis3316_histogram_start_ptr ) ;
			}

		}
	//} while((gl_stopReq == FALSE) );
	} while((loop_counter < stop_after_loop_counts) || (stop_after_loop_counts == 0));


	return_code = sis3316_adc1->register_write(SIS3316_KEY_DISARM , 0);  //

#ifdef raus
	BOOL gl_stopReq = FALSE;
	gl_stopReq = FALSE;
	do {
		gSystem->ProcessEvents();  // handle GUI events
	} while((gl_stopReq == FALSE) );
#endif

	printf("sampling finished   \n");



	do {
		gSystem->ProcessEvents();  // handle GUI events

	} while (1) ;



	return 0;
}




/***********************************************************************************************************************************************/
/***********************************************************************************************************************************************/
/***********************************************************************************************************************************************/

#define FILE_FORMAT_EVENT_HEADER        	0xDEADBEEF
#define FILE_FORMAT_EOF_TRAILER        		0x0E0F0E0F
int WriteBufferHeaderCounterNofChannelToDataFile (unsigned int indentifier, unsigned int bank_loop_no, unsigned int channel_no, unsigned int nof_events, unsigned int event_length, unsigned int maw_length, unsigned int reserved)
{
int written ;
int data ;
  //header
	data = FILE_FORMAT_EVENT_HEADER ;
    written=fwrite(&data,0x4,0x1,gl_FILE_DataEvenFilePointer); // write one  uint word
	written+=fwrite(&indentifier,0x4,0x1,gl_FILE_DataEvenFilePointer); // write one  uint word
   //Buffer No
    written+=fwrite(&bank_loop_no,0x4,0x1,gl_FILE_DataEvenFilePointer); // write one  uint word
    //channel  No
    written+=fwrite(&channel_no,0x4,0x1,gl_FILE_DataEvenFilePointer); // write one  uint word
    //nof events
    written+=fwrite(&nof_events,0x4,0x1,gl_FILE_DataEvenFilePointer); // write one  uint word
    //event length
    written+=fwrite(&event_length,0x4,0x1,gl_FILE_DataEvenFilePointer); // write one  uint word
    // maw buffer length
    written+=fwrite(&maw_length,0x4,0x1,gl_FILE_DataEvenFilePointer); // write one  uint word
    written+=fwrite(&reserved,0x4,0x1,gl_FILE_DataEvenFilePointer); // write one  uint word
 	return written;

}


//---------------------------------------------------------------------------
int WriteEventsToDataFile (unsigned int* memory_data_array, unsigned int nof_write_length_lwords)
{
int nof_write_elements ;
int written ;
//int data ;
//char messages_buffer[256] ;

// gl_uint_DataEvent_RunFile_EvenSize : length

		nof_write_elements = nof_write_length_lwords ;
		written=fwrite(memory_data_array,0x4,nof_write_elements,gl_FILE_DataEvenFilePointer); // write 3 uint value
		//gl_uint_DataEvent_LWordCounter = gl_uint_DataEvent_LWordCounter + written  ;
		if(nof_write_elements != written) {
    		printf ("Data File Write Error in  WriteEventToDataFile()  \n");
 		 }

 	return 0;

}

/***********************************************************************************************************************************************/
/***********************************************************************************************************************************************/

